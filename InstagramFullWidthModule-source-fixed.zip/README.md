# Instagram Full Width (experimental)

Targets `com.instagram.android`, logs when loaded, and requests MATCH_PARENT window/decor sizing when Instagram activities resume.

This can help only if Instagram's own window sizing constrains its content. It cannot directly override Huawei's privileged Magic Window/task bounds from inside Instagram. If Huawei imposes the outer task bounds, a system-side hook or different Huawei-specific workaround may be required.
