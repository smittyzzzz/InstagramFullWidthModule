package com.example.instagramfullwidth;

import android.app.Activity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.ViewGroup;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HookEntry implements IXposedHookLoadPackage {
    private static final String TARGET = "com.instagram.android";
    private static final String TAG = "InstagramFullWidthFix";

    private static void forceWindowSize(Window window) {
        if (window == null) return;
        try {
            WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.width = ViewGroup.LayoutParams.MATCH_PARENT;
            attrs.height = ViewGroup.LayoutParams.MATCH_PARENT;
            window.setAttributes(attrs);
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                             ViewGroup.LayoutParams.MATCH_PARENT);
            View decor = window.getDecorView();
            if (decor != null) {
                ViewGroup.LayoutParams lp = decor.getLayoutParams();
                if (lp != null) {
                    lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
                    lp.height = ViewGroup.LayoutParams.MATCH_PARENT;
                    decor.setLayoutParams(lp);
                }
                decor.requestLayout();
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": sizing error: " + t);
        }
    }

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": LOADED in " + lpparam.packageName);

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam param) {
                        Activity activity = (Activity) param.thisObject;
                        try {
                            forceWindowSize(activity.getWindow());
                            XposedBridge.log(TAG + ": applied to " + activity.getClass().getName());
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + ": onResume error: " + t);
                        }
                    }
                });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Activity.onResume hook failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(Window.class, "setLayout", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args != null && param.args.length >= 2) {
                        param.args[0] = ViewGroup.LayoutParams.MATCH_PARENT;
                        param.args[1] = ViewGroup.LayoutParams.MATCH_PARENT;
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Window.setLayout hook failed: " + t);
        }

        try {
            XposedBridge.hookAllMethods(Window.class, "setAttributes", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args != null && param.args.length > 0
                            && param.args[0] instanceof WindowManager.LayoutParams) {
                        WindowManager.LayoutParams attrs = (WindowManager.LayoutParams) param.args[0];
                        attrs.width = ViewGroup.LayoutParams.MATCH_PARENT;
                        attrs.height = ViewGroup.LayoutParams.MATCH_PARENT;
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Window.setAttributes hook failed: " + t);
        }
    }
}
